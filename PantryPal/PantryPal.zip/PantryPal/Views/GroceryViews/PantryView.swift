//
//  Pantry.swift
//  PantryPal
//
//  Created by Russell Tan on 2024-02-10.
//

import SwiftUI
import Photos
import FirebaseStorage

struct PantryView: View {
    @State private var selection = 0
    @State private var items = [UIImage]()
    
    @EnvironmentObject var recipeManager : RecipeManager
    @EnvironmentObject var dbHelper : FireDBHelper

    var body: some View {
        TabView(selection: $selection) {
            NavigationView {
                List {
/*                    ForEach(self.dbHelper.ingredientList.enumerated().map({$0}), id: \.element.self) {index, item in
                       // NavigationLink(destination: GroceryDetails(item: item.ingredientName, image: "apple.logo").environmentObject(self.dbHelper)) {
                         //   ListItem(image: "apple.logo", name: item.ingredientName)
                        NavigationLink {
                            GroceryDetails(selectedIngredientIndex : index).environmentObject(self.dbHelper)
                        }label: {
                            ListItem(image: item.ingredientImage, name: item.ingredientName)
                        }//NavigationLink
                    }*/
                    ForEach(Array(zip(dbHelper.retrivedImages, dbHelper.ingredientList)), id: \.0) { image, ingredient in
                        // NavigationLink(destination: GroceryDetails(item: item.ingredientName, image: "apple.logo").environmentObject(self.dbHelper)) {
                          //   ListItem(image: "apple.logo", name: item.ingredientName)
                        /* NavigationLink {
                             GroceryDetails(selectedIngredientIndex : index).environmentObject(self.dbHelper)
                         }label: {
                            // ListItem(image: item.ingredientImage, name: item.ingredientName)
                         }//NavigationLink
                        */
                        
                        HStack {
                            Image(uiImage: image)
                                .resizable()
                                .frame(width: 100, height: 100) // Adjust size as needed
                            
                            VStack(alignment: .leading) {
                                Text(ingredient.ingredientName) // Assuming 'ingredientName' is a property of Ingredient
                                    .font(.headline)
                                // Display other properties of Ingredient as needed
                            }
                        }
                    }
                    .onDelete(){indexSet in
                        for index in indexSet{
                            print(#function, "Trying to delete ingredient : \(self.dbHelper.ingredientList[index].ingredientName)")
                            
                            //delete the ingredient from database
                            self.dbHelper.deleteIngredient(docIDtoDelete : self.dbHelper.ingredientList[index].id!)
                        }
                    }

                }
                .navigationBarTitle("Pantry List")
                .navigationBarItems(trailing:
                    NavigationLink(destination: NewGroceryView()) {
                        Image(systemName: "plus")
                    }
                )
            }
            .tabItem {
                Image(systemName: "list.dash")
                Text("Pantry List")
            }
            
            NavigationView {
                RecipeView()
                    .environmentObject(recipeManager)
                    .environmentObject(dbHelper)
            }
            .tabItem {
                Image(systemName: "list.dash")
                Text("Recipes")
            }
        }
        .onAppear(){
            //get all Ingredients from database
            self.dbHelper.retrieveAllIngredients()
            self.dbHelper.retrieveImages()
        }//onAppear
    }
}

struct ListItem: View {
    var image: String
    var name: String
    
    var body: some View {
        HStack {
            Image(systemName: "apple.logo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 50, height: 50)
                .cornerRadius(25)
            Text(name)
        }
    }
}

